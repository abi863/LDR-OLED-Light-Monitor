#define BLYNK_TEMPLATE_ID "YTMPL3uL17GEhr"
#define BLYNK_TEMPLATE_NAME "esp32 led"
#define BLYNK_AUTH_TOKEN "UatR-sPOvmZDIfTW1MCLVbNYN4lI13d5"

#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

char ssid[] = "Wokwi-GUEST";
char pass[] = "";

#define LED_PIN 2

BLYNK_CONNECTED()
{
  Serial.println(">>> BLYNK CONNECTED <<<");
}

BLYNK_WRITE(V0)
{
  int value = param.asInt();

  digitalWrite(LED_PIN, value);

  Serial.print("V0 = ");
  Serial.println(value);

  if (value == 1)
    Serial.println("LED ON");
  else
    Serial.println("LED OFF");
}

void setup()
{
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
}

void loop()
{
  Blynk.run();
}